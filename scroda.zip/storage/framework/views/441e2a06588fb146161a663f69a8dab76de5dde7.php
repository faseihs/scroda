<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php echo $__env->make('includes.flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-md-12 table-responsive">
            <?php if(sizeof($requests)>0): ?>
                <table class="table">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Approve</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($request->user->name); ?></td>

                            <td>

                                <form id="logout-form<?php echo e($index); ?>" action="/admin/assign-address" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <input placeholder="Enter Address (Without Spaces)" required pattern="[^' ']+" name="address" class="form-control" type="text">
                                    <input name="address_id" value="<?php echo e($request->id); ?>" type="hidden">
                                </form>
                            </td>

                            <td>
                                <a href="/admin/assign-address" class="btn btn-primary btn-sm"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form<?php echo e($index); ?>').submit();">
                                    <i class="ti ti-check"></i>
                                </a>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            <?php else: ?>

                <div class="alert alert-warning">
                    No Requests
                </div>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
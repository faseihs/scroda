<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 table-responsive">
            <?php if(sizeof($clients)>0): ?>
            <table class="table">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subscribed</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($client->name); ?></td>
                            <td><?php echo e($client->email); ?></td>
                            <td><?php echo $client->subscribed==0?'<i class="ti ti-close"></i>' :'<i class="ti ti-check"></i>'; ?></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php else: ?>

                <div class="alert alert-warning">
                    No Clients
                </div>

            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>